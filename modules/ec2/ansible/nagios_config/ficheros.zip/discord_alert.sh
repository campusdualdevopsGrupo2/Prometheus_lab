#!/bin/bash

WEBHOOK_URL="YOUR_DISCORD_WEBHOOK_URL"   # Replace with your Discord webhook URL
MESSAGE="Nagios Alert - $1 $2 $3"         # Format the message with relevant details

curl -X POST -H "Content-Type: application/json" \
  -d "{"content": "$MESSAGE"}" \
  $WEBHOOK_URL